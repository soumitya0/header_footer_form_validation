import { Button } from "@material-ui/core";
import { Component } from "react";
import classes from "./Auth.module.css";

import Login from "./Login/Login";

import Register from "./Register/Register";
class Auth extends Component {
  state = { mode: "" };

  onSwitchMode = () => {
    if (this.state.mode === "register") {
      this.setState({ mode: "login" });
    } else {
      this.setState({ mode: "register" });
    }
  };

  render() {
    return (
      <div>
        {this.state.mode === "register" ? <Register /> : <Login />}

        <div className={classes["form-buttons"]}>
          <Button onClick={this.onSwitchMode} variant="outlined">
            {this.state.mode == "register"
              ? "Switch to login"
              : "Switch to Register"}
          </Button>
        </div>
      </div>
    );
  }
}
export default Auth;
