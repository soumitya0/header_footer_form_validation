import React, { Component } from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "@material-ui/core/Button";
import classes from "../Auth.module.css";

import { addUser } from "../../../utils/users";
class Register extends Component {
  state = {
    userName: "",
    password: "",
    role: "admin",
  };

  onChangeHandler = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value }, () => {
      // console.log(this.state);
    });
  };

  onRegister = (e) => {
    e.preventDefault();
    const { userName, password, role } = this.state;
    if (!userName || !password) {
      return;
    }

    const user = { userName: userName.toLowerCase(), password, role };
    //register

    const responce = addUser(user);

    console.log(responce);
    this.setState({
      userName: "",
      password: "",
      role: "admin",
    });
  };

  render() {
    return (
      <div className={classes["auth-form"]}>
        <h4>Registeration Form</h4>
        <form noValidate autoComplete="off" onSubmit={this.onRegister}>
          <TextField
            label="User Name"
            type="text"
            margin="normal"
            variant="outlined"
            name="userName"
            value={this.state.userName}
            onChange={this.onChangeHandler}
          />
          <TextField
            label="password"
            type="password"
            margin="normal"
            variant="outlined"
            name="password"
            value={this.state.password}
            onChange={this.onChangeHandler}
          />
          <TextField
            select
            variant="outlined"
            label="Role"
            name="role"
            value={this.state.role}
            onChange={this.onChangeHandler}
          >
            <MenuItem value="admin">Administrator</MenuItem>
            <MenuItem value="dev">Developer</MenuItem>
            <MenuItem value="guest">Guest</MenuItem>
          </TextField>

          <Button variant="contained" color="primary" type="submit">
            Submit
          </Button>
        </form>
      </div>
    );
  }
}

export default Register;
