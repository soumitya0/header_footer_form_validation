import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import classes from "../Auth.module.css";

function Login() {
  return (
    <div className={classes["auth-form"]}>
      <h4>Login form</h4>
      <form noValidate autoComplete="off">
        <TextField
          label="User Name"
          type="text"
          margin="normal"
          variant="outlined"
        />
        <TextField
          label="password"
          type="password"
          margin="normal"
          variant="outlined"
        />
        <TextField select variant="outlined" label="Role">
          <MenuItem value="admin">Administrator</MenuItem>
          <MenuItem value="dev">Developer</MenuItem>
          <MenuItem value="guest">Guest</MenuItem>
        </TextField>
      </form>
    </div>
  );
}
export default Login;
