import classes from "./Posts.module.css";

function Posts() {
  return <h1>Posts</h1>;
}
export default Posts;
