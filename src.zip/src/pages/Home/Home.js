import classes from "./Home.module.css";
function Home() {
  return <h1 className={classes.h1class}>Home</h1>;
}
export default Home;
