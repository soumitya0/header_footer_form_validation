import classes from "./PageNotFound.module.css";

function PageNotFound() {
  return <h1>PageNotFound</h1>;
}
export default PageNotFound;
