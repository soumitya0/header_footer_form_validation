const register = [{ userName: "jhon", token: "qwerty", role: "admin" }];

const checkIfUserExists = (user) => {
  const existingUser = register.find((registerUser) => {
    return registerUser.userName == user.userName;
  });

  return existingUser;
};

const resiterUser = (user) => {
  const newUser = {
    userName: user.userName,
    token: user.password,
    role: user.role,
  };

  register.push(newUser);
};

export const addUser = (user) => {
  if (checkIfUserExists(user)) {
    return "User Exists";
  } else {
    resiterUser(user);
    return "User Added";
  }
};
